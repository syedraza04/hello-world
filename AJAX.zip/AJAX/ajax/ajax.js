

"use strict";


(function (){
	
	
	
	document.getElementById("myButton").addEventListener('click',getData,true);

	
	function getData(){
		
		var httpRequest= new XMLHttpRequest();
		//var httpRequest= new XMLHttpRequest();
		httpRequest.open('GET','dummyServer/obj.json',true);
		//httpRequest.send(null);
		
		httpRequest.onreadystatechange = readyChanged;
		
		function readyChanged(){
			
			console.log(httpRequest.readyState);
			if(httpRequest.readyState === 4)
			{
				if(httpRequest.status === 200)
				{
					// console.log();
					var resp = JSON.parse(httpRequest.responseText);
					
					document.getElementById("title").innerText = resp.insuarance.name;
					document.getElementById("title2").innerText = resp.insuarance.city;
					document.getElementById("title3").innerText = resp.insuarance.state;
				}
				
				
			}
		}
		
	}
	
	
	
	















})()

